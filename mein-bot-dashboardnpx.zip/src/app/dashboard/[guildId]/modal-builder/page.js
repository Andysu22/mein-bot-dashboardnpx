"use client";

import React, { useMemo, useState } from "react";
import { create } from "zustand";
import { nanoid } from "nanoid";

import { DndContext, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

/**
 * --------- Store (Zustand) ----------
 */
function defaultInput() {
  const id = nanoid();
  return {
    id,
    custom_id: `input_${id.slice(0, 8)}`,
    label: "Text Input",
    style: 1, // 1 = Short, 2 = Paragraph
    required: true,
    placeholder: "",
    min_length: undefined,
    max_length: undefined,
    value: "",
  };
}

const useBuilderStore = create((set, get) => ({
  modal: {
    title: "Modal",
    custom_id: "modal",
    inputs: [defaultInput()],
  },

  setTitle: (title) => set((s) => ({ modal: { ...s.modal, title } })),
  setCustomId: (custom_id) => set((s) => ({ modal: { ...s.modal, custom_id } })),

  addTextInput: () =>
    set((s) => ({
      modal: { ...s.modal, inputs: [...s.modal.inputs, defaultInput()] },
    })),

  removeInput: (id) =>
    set((s) => ({
      modal: { ...s.modal, inputs: s.modal.inputs.filter((x) => x.id !== id) },
    })),

  updateInput: (id, patch) =>
    set((s) => ({
      modal: {
        ...s.modal,
        inputs: s.modal.inputs.map((x) => (x.id === id ? { ...x, ...patch } : x)),
      },
    })),

  reorderInputs: (activeId, overId) => {
    const { modal } = get();
    const from = modal.inputs.findIndex((x) => x.id === activeId);
    const to = modal.inputs.findIndex((x) => x.id === overId);
    if (from < 0 || to < 0 || from === to) return;

    const next = [...modal.inputs];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);

    set({ modal: { ...modal, inputs: next } });
  },
}));

/**
 * --------- JSON Builder ----------
 * Discord Modal shape: components = ActionRows, jede Row enthält genau ein TextInput
 */
function buildDiscordModalJSON(modal) {
  return {
    title: modal.title,
    custom_id: modal.custom_id,
    components: modal.inputs.map((input) => ({
      type: 1,
      components: [
        {
          type: 4,
          custom_id: input.custom_id,
          label: input.label,
          style: input.style,
          required: input.required ? true : undefined,
          placeholder: input.placeholder || undefined,
          min_length: input.min_length ?? undefined,
          max_length: input.max_length ?? undefined,
          value: input.value || undefined,
        },
      ],
    })),
  };
}

function pretty(obj) {
  return JSON.stringify(obj, null, 2);
}

/**
 * --------- Sortable Card ----------
 */
function SortableInputCard({ inputId }) {
  const { modal, updateInput, removeInput } = useBuilderStore();
  const input = modal.inputs.find((x) => x.id === inputId);
  if (!input) return null;

  const sortable = useSortable({ id: input.id });

  const style = {
    transform: CSS.Transform.toString(sortable.transform),
    transition: sortable.transition,
  };

  return (
    <div
      ref={sortable.setNodeRef}
      style={style}
      className={[
        "rounded-2xl bg-zinc-950/30 p-3 ring-1 ring-white/10",
        sortable.isDragging ? "ring-2 ring-indigo-500" : "",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <button
          {...sortable.attributes}
          {...sortable.listeners}
          className="mt-0.5 select-none rounded-xl bg-zinc-800 px-2 py-1 text-xs text-zinc-200 hover:bg-zinc-700"
          title="Drag"
          type="button"
        >
          ⋮⋮
        </button>

        <div className="flex-1 space-y-3">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">Label</span>
              <input
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.label}
                onChange={(e) => updateInput(input.id, { label: e.target.value })}
              />
            </label>

            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">custom_id</span>
              <input
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.custom_id}
                onChange={(e) => updateInput(input.id, { custom_id: e.target.value })}
              />
            </label>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">Style</span>
              <select
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.style}
                onChange={(e) => updateInput(input.id, { style: Number(e.target.value) })}
              >
                <option value={1}>Short</option>
                <option value={2}>Paragraph</option>
              </select>
            </label>

            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">Required</span>
              <select
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.required ? "yes" : "no"}
                onChange={(e) => updateInput(input.id, { required: e.target.value === "yes" })}
              >
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </label>

            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">Placeholder</span>
              <input
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.placeholder || ""}
                onChange={(e) => updateInput(input.id, { placeholder: e.target.value })}
              />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">min_length</span>
              <input
                type="number"
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.min_length ?? ""}
                onChange={(e) =>
                  updateInput(input.id, {
                    min_length: e.target.value === "" ? undefined : Number(e.target.value),
                  })
                }
              />
            </label>

            <label className="grid gap-1">
              <span className="text-[11px] text-zinc-400">max_length</span>
              <input
                type="number"
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.max_length ?? ""}
                onChange={(e) =>
                  updateInput(input.id, {
                    max_length: e.target.value === "" ? undefined : Number(e.target.value),
                  })
                }
              />
            </label>

            <label className="col-span-2 grid gap-1">
              <span className="text-[11px] text-zinc-400">Prefilled value</span>
              <input
                className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                value={input.value || ""}
                onChange={(e) => updateInput(input.id, { value: e.target.value })}
              />
            </label>
          </div>
        </div>

        <button
          onClick={() => removeInput(input.id)}
          className="rounded-xl bg-zinc-800 px-3 py-2 text-xs font-semibold hover:bg-zinc-700"
          title="Remove"
          type="button"
        >
          ✕
        </button>
      </div>
    </div>
  );
}

/**
 * --------- Components Editor (Drag&Drop) ----------
 */
function ComponentsEditor() {
  const { modal, reorderInputs } = useBuilderStore();

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } })
  );

  function onDragEnd(event) {
    const activeId = String(event.active.id);
    const overId = event.over?.id ? String(event.over.id) : null;
    if (!overId) return;
    reorderInputs(activeId, overId);
  }

  return (
    <DndContext sensors={sensors} onDragEnd={onDragEnd}>
      <SortableContext items={modal.inputs.map((x) => x.id)} strategy={verticalListSortingStrategy}>
        <div className="space-y-3">
          {modal.inputs.map((input) => (
            <SortableInputCard key={input.id} inputId={input.id} />
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
}

/**
 * --------- Discord Preview ----------
 */
function DiscordPreview() {
  const { modal } = useBuilderStore();

  return (
    <div className="flex items-center justify-center">
      <div className="w-full max-w-md rounded-2xl bg-zinc-900 ring-1 ring-white/10">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-indigo-600/80" />
            <div className="font-semibold">{modal.title || "Modal"}</div>
          </div>
          <div className="text-zinc-400">✕</div>
        </div>

        <div className="space-y-3 p-4">
          {modal.inputs.map((i) => (
            <div key={i.id} className="space-y-1">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-zinc-300">
                {(i.label || "Text Input") + (i.required ? " *" : "")}
              </div>
              <div
                className={[
                  "rounded-xl bg-zinc-950/40 px-3 py-2 text-sm text-zinc-200 ring-1 ring-white/10",
                  i.style === 2 ? "h-20" : "h-9",
                ].join(" ")}
              >
                <span className="text-zinc-500">{i.placeholder || ""}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-3 border-t border-white/10 p-4">
          <button
            className="flex-1 rounded-xl bg-zinc-800 px-3 py-2 text-sm font-semibold hover:bg-zinc-700"
            type="button"
          >
            Cancel
          </button>
          <button
            className="flex-1 rounded-xl bg-indigo-600 px-3 py-2 text-sm font-semibold hover:bg-indigo-500"
            type="button"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}

/**
 * --------- Page / Layout ----------
 */
export default function ModalBuilderPage() {
  const { modal, setTitle, setCustomId, addTextInput } = useBuilderStore();
  const json = useMemo(() => buildDiscordModalJSON(modal), [modal]);

  const [copied, setCopied] = useState(false);

  async function copy() {
    await navigator.clipboard.writeText(pretty(json));
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-6xl p-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Left: Editor */}
          <div className="rounded-2xl bg-zinc-900/60 shadow-sm ring-1 ring-white/10">
            <div className="border-b border-white/10 p-4">
              <div className="text-sm font-semibold">Modal</div>

              <div className="mt-3 grid gap-3">
                <label className="grid gap-1">
                  <span className="text-xs text-zinc-400">Title</span>
                  <input
                    className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                    value={modal.title}
                    onChange={(e) => setTitle(e.target.value)}
                    maxLength={45}
                  />
                </label>

                <label className="grid gap-1">
                  <span className="text-xs text-zinc-400">custom_id</span>
                  <input
                    className="rounded-xl bg-zinc-950/40 px-3 py-2 text-sm ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-indigo-500"
                    value={modal.custom_id}
                    onChange={(e) => setCustomId(e.target.value)}
                  />
                </label>

                <div className="flex items-center justify-between">
                  <div className="text-xs text-zinc-400">
                    Components ({modal.inputs.length})
                  </div>
                  <button
                    onClick={addTextInput}
                    className="rounded-xl bg-indigo-600 px-3 py-2 text-xs font-semibold hover:bg-indigo-500"
                    type="button"
                  >
                    Add Text Input
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4">
              <ComponentsEditor />
            </div>
          </div>

          {/* Right: Preview + JSON */}
          <div className="space-y-6">
            <div className="rounded-2xl bg-zinc-900/60 shadow-sm ring-1 ring-white/10">
              <div className="border-b border-white/10 p-4 text-sm font-semibold">Preview</div>
              <div className="p-4">
                <DiscordPreview />
              </div>
            </div>

            <div className="rounded-2xl bg-zinc-900/60 shadow-sm ring-1 ring-white/10">
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div className="text-sm font-semibold">Code (JSON)</div>
                <button
                  onClick={copy}
                  className="rounded-xl bg-zinc-800 px-3 py-2 text-xs font-semibold hover:bg-zinc-700"
                  type="button"
                >
                  {copied ? "Copied" : "Copy JSON"}
                </button>
              </div>

              <pre className="max-h-[420px] overflow-auto p-4 text-xs leading-5 text-zinc-200">
                {pretty(json)}
              </pre>
            </div>
          </div>
        </div>

        <div className="mt-6 text-xs text-zinc-500">
          Hinweis: Discord-Modals bestehen aus Action Rows; jede Row enthält genau ein TextInput.
        </div>
      </div>
    </div>
  );
}
